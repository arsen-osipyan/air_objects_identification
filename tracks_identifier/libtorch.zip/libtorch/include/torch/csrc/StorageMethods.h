#ifndef THP_STORAGE_METHODS_INC
#define THP_STORAGE_METHODS_INC

#include <Python.h>

PyMethodDef* THPStorage_getMethods();

#endif
